/* ============================================================
   Ridgeline — data layer
   Everything persists to localStorage so the whole LMS runs
   with zero backend. Seed data is written once on first load.
   ============================================================ */

const DB_KEYS = {
  USERS: 'ridge_users',
  SESSION: 'ridge_session',
  COURSES: 'ridge_courses',
  ENROLL: 'ridge_enrollments',   // { userId: [courseId, ...] }
  PROGRESS: 'ridge_progress',    // { userId: { courseId: [lessonId, ...] } }
  SEEDED: 'ridge_seeded_v1'
};

function loadJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) {
    return fallback;
  }
}
function saveJSON(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

/* ---------- seed content ---------- */
function seedIfNeeded() {
  if (loadJSON(DB_KEYS.SEEDED, false)) return;

  const users = [
    { id: 'u-instructor', name: 'Mara Solis', email: 'mara@ridgeline.edu', password: 'trailblazer', role: 'instructor' },
    { id: 'u-student', name: 'Jordan Pike', email: 'jordan@ridgeline.edu', password: 'summit123', role: 'student' }
  ];

  const courses = [
    {
      id: 'c-cartography',
      title: 'Cartography for Data Storytellers',
      subtitle: 'Turn raw datasets into maps people actually understand.',
      category: 'Data & Analysis',
      difficulty: 'Intermediate',
      instructorId: 'u-instructor',
      cover: 'map',
      summary: 'A practical route through projection choices, color encoding, and the small decisions that make a map lie or tell the truth.',
      modules: [
        {
          id: 'm1', title: 'Base Camp: Reading a Map Critically',
          lessons: [
            { id: 'l1', type: 'reading', title: 'Why every map is an argument', duration: 8,
              body: 'Every map projects a curved world onto a flat surface, and every projection distorts something — area, shape, distance, or direction. Before you build a map, decide which distortion you can live with. A map for navigation prizes shape and angle. A map for comparing country sizes prizes area. Naming the trade-off up front is the first honest thing a mapmaker does.' },
            { id: 'l2', type: 'video', title: 'Projections in five minutes', duration: 5,
              body: 'This lesson walks through Mercator, Albers, and Robinson projections side by side, using the same coastline outline so distortion is visible at a glance.' },
            { id: 'l3', type: 'quiz', title: 'Checkpoint: Projections', duration: 4,
              quiz: {
                question: 'Which projection is famous for exaggerating the size of countries far from the equator?',
                options: ['Albers Equal-Area', 'Mercator', 'Robinson', 'Azimuthal Equidistant'],
                answerIndex: 1
              } }
          ]
        },
        {
          id: 'm2', title: 'Ridge Line: Color and Encoding',
          lessons: [
            { id: 'l4', type: 'reading', title: 'Sequential vs. diverging palettes', duration: 6,
              body: 'Use a sequential palette (light to dark, one hue) when your data runs from low to high with no meaningful midpoint. Use a diverging palette (two hues meeting at a neutral center) when there is a real zero or baseline, like temperature change from average.' },
            { id: 'l5', type: 'video', title: 'Building a choropleth step by step', duration: 11,
              body: 'A hands-on walkthrough building a county-level choropleth map, from binning the data to picking break points that do not mislead.' },
            { id: 'l6', type: 'quiz', title: 'Checkpoint: Color Encoding', duration: 4,
              quiz: {
                question: 'A dataset of temperature change from a 30-year average is best shown with which palette type?',
                options: ['Sequential', 'Diverging', 'Categorical', 'Random'],
                answerIndex: 1
              } }
          ]
        },
        {
          id: 'm3', title: 'Summit: Publishing Your Map',
          lessons: [
            { id: 'l7', type: 'reading', title: 'Annotation and the honest legend', duration: 7,
              body: 'A legend is not decoration — it is the map admitting how it was built. Always show your bins, your source, and your projection choice somewhere on the page, even in small type.' },
            { id: 'l8', type: 'quiz', title: 'Final Checkpoint: Publishing', duration: 5,
              quiz: {
                question: 'What should a trustworthy map legend disclose at minimum?',
                options: ['Only the title', 'Bins, source, and projection', 'Just the author name', 'Nothing — legends are optional'],
                answerIndex: 1
              } }
          ]
        }
      ]
    },
    {
      id: 'c-fermentation',
      title: 'The Chemistry of Fermentation',
      subtitle: 'Understand the microbiology behind bread, yogurt, and kimchi.',
      category: 'Science',
      difficulty: 'Beginner',
      instructorId: 'u-instructor',
      cover: 'flask',
      summary: 'A trail through wild yeasts, lactic acid bacteria, and the conditions that decide whether a jar turns delicious or dangerous.',
      modules: [
        {
          id: 'm1', title: 'Base Camp: Microbes 101',
          lessons: [
            { id: 'l1', type: 'reading', title: 'Meet your microscopic crew', duration: 6,
              body: 'Fermentation is controlled spoilage. Yeasts convert sugar into alcohol and carbon dioxide. Lactic acid bacteria convert sugar into acid. Both crowd out the organisms that would otherwise rot your food, which is why fermentation is one of the oldest preservation techniques humans have.' },
            { id: 'l2', type: 'quiz', title: 'Checkpoint: Microbes', duration: 3,
              quiz: {
                question: 'What do lactic acid bacteria primarily produce during fermentation?',
                options: ['Alcohol', 'Acid', 'Sugar', 'Oxygen'],
                answerIndex: 1
              } }
          ]
        },
        {
          id: 'm2', title: 'Ridge Line: Salt, Time, and Temperature',
          lessons: [
            { id: 'l3', type: 'video', title: 'Why salt percentage matters', duration: 9,
              body: 'Salt controls the pace of fermentation and selects for salt-tolerant bacteria. Too little salt invites the wrong microbes; too much halts fermentation entirely.' },
            { id: 'l4', type: 'reading', title: 'Cold ferments vs. warm ferments', duration: 5,
              body: 'Cooler temperatures slow fermentation and favor more complex, layered flavor. Warmer temperatures speed things up but can produce a flatter, more one-note result.' },
            { id: 'l5', type: 'quiz', title: 'Checkpoint: Environment', duration: 4,
              quiz: {
                question: 'A slower, cooler ferment typically produces:',
                options: ['No flavor at all', 'A flatter, one-note flavor', 'More complex, layered flavor', 'Only spoilage'],
                answerIndex: 2
              } }
          ]
        }
      ]
    },
    {
      id: 'c-negotiation',
      title: 'Negotiation for Independent Contractors',
      subtitle: 'Price your work and hold your line without losing the client.',
      category: 'Business',
      difficulty: 'Beginner',
      instructorId: 'u-instructor',
      cover: 'handshake',
      summary: 'A short, practical trail covering scope, anchoring, and how to say no to scope creep without sounding difficult.',
      modules: [
        {
          id: 'm1', title: 'Base Camp: Know Your Number',
          lessons: [
            { id: 'l1', type: 'reading', title: 'Set a floor before the call', duration: 5,
              body: 'Decide your walk-away rate before you are on the phone with a client. A number decided in the moment is a number under pressure, and pressure favors the other side.' },
            { id: 'l2', type: 'video', title: 'Anchoring without overreaching', duration: 7,
              body: 'The first number spoken sets the frame for the whole negotiation. This lesson covers how to anchor high enough to leave room, without naming a figure so high it ends the conversation.' }
          ]
        },
        {
          id: 'm2', title: 'Summit: Holding the Line',
          lessons: [
            { id: 'l3', type: 'reading', title: 'Scope creep is a pricing conversation', duration: 6,
              body: 'When a client adds requests mid-project, the answer is rarely a flat no. It is: "Happy to add that — here is what it does to the timeline and the invoice."' },
            { id: 'l4', type: 'quiz', title: 'Final Checkpoint', duration: 3,
              quiz: {
                question: 'The best response to unplanned scope creep is usually to:',
                options: ['Refuse any changes', 'Absorb it silently to keep the client happy', 'Name the added cost and timeline impact', 'End the contract immediately'],
                answerIndex: 2
              } }
          ]
        }
      ]
    }
  ];

  saveJSON(DB_KEYS.USERS, users);
  saveJSON(DB_KEYS.COURSES, courses);
  saveJSON(DB_KEYS.ENROLL, { 'u-student': ['c-cartography'] });
  saveJSON(DB_KEYS.PROGRESS, { 'u-student': { 'c-cartography': ['l1', 'l2'] } });
  saveJSON(DB_KEYS.SEEDED, true);
}

seedIfNeeded();

/* ---------- accessors ---------- */
const DB = {
  users: () => loadJSON(DB_KEYS.USERS, []),
  saveUsers: (u) => saveJSON(DB_KEYS.USERS, u),
  courses: () => loadJSON(DB_KEYS.COURSES, []),
  saveCourses: (c) => saveJSON(DB_KEYS.COURSES, c),
  enrollments: () => loadJSON(DB_KEYS.ENROLL, {}),
  saveEnrollments: (e) => saveJSON(DB_KEYS.ENROLL, e),
  progress: () => loadJSON(DB_KEYS.PROGRESS, {}),
  saveProgress: (p) => saveJSON(DB_KEYS.PROGRESS, p),

  getCourse: (id) => DB.courses().find(c => c.id === id),

  courseLessonIds: (course) => course.modules.flatMap(m => m.lessons.map(l => l.id)),

  isEnrolled: (userId, courseId) => (DB.enrollments()[userId] || []).includes(courseId),

  enroll: (userId, courseId) => {
    const e = DB.enrollments();
    e[userId] = e[userId] || [];
    if (!e[userId].includes(courseId)) e[userId].push(courseId);
    DB.saveEnrollments(e);
  },

  completedLessons: (userId, courseId) => (DB.progress()[userId] || {})[courseId] || [],

  markComplete: (userId, courseId, lessonId) => {
    const p = DB.progress();
    p[userId] = p[userId] || {};
    p[userId][courseId] = p[userId][courseId] || [];
    if (!p[userId][courseId].includes(lessonId)) p[userId][courseId].push(lessonId);
    DB.saveProgress(p);
  },

  courseProgressPct: (userId, course) => {
    const total = DB.courseLessonIds(course).length;
    if (!total) return 0;
    const done = DB.completedLessons(userId, course.id).length;
    return Math.round((done / total) * 100);
  }
};
