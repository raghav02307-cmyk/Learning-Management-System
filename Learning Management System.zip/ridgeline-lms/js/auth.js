/* ============================================================
   Ridgeline — auth layer (client-side demo auth, no backend)
   ============================================================ */

const Auth = {
  currentUser: () => loadJSON(DB_KEYS.SESSION, null),

  login: (email, password) => {
    const user = DB.users().find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
    if (!user) return { ok: false, error: 'That email and password combination doesn\u2019t match our records.' };
    saveJSON(DB_KEYS.SESSION, { id: user.id, name: user.name, email: user.email, role: user.role });
    return { ok: true };
  },

  signup: (name, email, password) => {
    const users = DB.users();
    if (users.some(u => u.email.toLowerCase() === email.toLowerCase())) {
      return { ok: false, error: 'An account with that email already exists.' };
    }
    const id = 'u-' + Math.random().toString(36).slice(2, 9);
    const user = { id, name, email, password, role: 'student' };
    users.push(user);
    DB.saveUsers(users);
    saveJSON(DB_KEYS.SESSION, { id: user.id, name: user.name, email: user.email, role: user.role });
    return { ok: true };
  },

  logout: () => {
    localStorage.removeItem(DB_KEYS.SESSION);
    window.location.href = 'index.html';
  },

  requireAuth: () => {
    const u = Auth.currentUser();
    if (!u) { window.location.href = 'index.html'; return null; }
    return u;
  },

  requireInstructor: () => {
    const u = Auth.requireAuth();
    if (u && u.role !== 'instructor') { window.location.href = 'dashboard.html'; return null; }
    return u;
  }
};
