/* ============================================================
   Ridgeline — shared UI helpers
   ============================================================ */

const Icons = {
  map: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M9 20l-6-2V4l6 2 6-2 6 2v14l-6-2-6 2z"/><path d="M9 4v16M15 6v16"/></svg>',
  flask: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M9 3h6M10 3v6l-6 10a1.5 1.5 0 0 0 1.3 2.2h13.4A1.5 1.5 0 0 0 20 19L14 9V3"/><path d="M7.5 15h9"/></svg>',
  handshake: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M8 12l3 3 7-7"/><path d="M3 11l4-4 4 2 3-2 4 3-3 3"/><path d="M7 15l2 2a2 2 0 0 0 3 0l1-1"/></svg>',
  peak: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M3 19l6-11 3 5 2-3 7 9H3z"/></svg>'
};

function brandMark() {
  return `<svg class="brand-mark" viewBox="0 0 32 32" fill="none">
    <path d="M2 25L12 8l5 8 3-4 10 13H2z" fill="#3E6B50"/>
    <path d="M17 16l3-4 10 13H17l-3-5z" fill="#DE9F3B"/>
  </svg>`;
}

function renderNav(activePage) {
  const el = document.getElementById('topnav');
  if (!el) return;
  const user = Auth.currentUser();
  const links = user ? [
    { href: 'dashboard.html', label: 'Dashboard', key: 'dashboard' },
    { href: 'courses.html', label: 'Catalog', key: 'courses' },
  ] : [];
  if (user && user.role === 'instructor') links.push({ href: 'admin.html', label: 'Instructor Studio', key: 'admin' });

  const linksHtml = links.map(l =>
    `<a class="nav-link ${l.key === activePage ? 'active' : ''}" href="${l.href}">${l.label}</a>`
  ).join('');

  const userHtml = user ? `
    <div class="nav-user">
      <div class="avatar">${user.name.split(' ').map(p => p[0]).join('').slice(0,2).toUpperCase()}</div>
      <a href="#" class="nav-link" id="logoutBtn">Log out</a>
    </div>` : `
    <div class="nav-user" style="border-left:none;padding-left:0;">
      <a class="btn btn-ghost btn-small" href="index.html">Log in</a>
    </div>`;

  el.innerHTML = `
    <div class="topnav-inner">
      <a class="brand" href="${user ? 'dashboard.html' : 'index.html'}">${brandMark()}Ridgeline</a>
      <nav class="nav-links">${linksHtml}</nav>
      ${userHtml}
    </div>`;

  const logout = document.getElementById('logoutBtn');
  if (logout) logout.addEventListener('click', (e) => { e.preventDefault(); Auth.logout(); });
}

/* ---------- signature element: elevation-profile trail ---------- */
function trailSvg(lessons, completedIds, currentId, opts) {
  opts = opts || {};
  const width = opts.width || 220;
  const height = opts.height || 46;
  const n = lessons.length;
  if (n === 0) return '';
  const pad = 16;
  const usable = width - pad * 2;
  const step = n > 1 ? usable / (n - 1) : 0;

  // simple deterministic "elevation" wiggle so it reads as a trail, not a straight line
  const points = lessons.map((l, i) => {
    const x = pad + step * i;
    const wiggle = Math.sin(i * 1.7) * (height * 0.18);
    const y = height * 0.55 - wiggle - (i / Math.max(n - 1, 1)) * (height * 0.28);
    return { x, y: Math.max(8, y), lesson: l };
  });

  const pathD = points.map((p, i) => (i === 0 ? `M${p.x},${p.y}` : `L${p.x},${p.y}`)).join(' ');

  let lastDoneIdx = -1;
  points.forEach((p, i) => { if (completedIds.includes(p.lesson.id)) lastDoneIdx = i; });
  const donePath = lastDoneIdx >= 0
    ? points.slice(0, lastDoneIdx + 1).map((p, i) => (i === 0 ? `M${p.x},${p.y}` : `L${p.x},${p.y}`)).join(' ')
    : '';

  const circles = points.map(p => {
    const done = completedIds.includes(p.lesson.id);
    const cur = p.lesson.id === currentId;
    const cls = done ? 'checkpoint done' : (cur ? 'checkpoint current' : 'checkpoint');
    return `<circle class="${cls}" cx="${p.x}" cy="${p.y}" r="4.5"><title>${escapeHtml(p.lesson.title)}</title></circle>`;
  }).join('');

  return `<svg class="trail-svg" viewBox="0 0 ${width} ${height}" width="100%" height="${height}">
    <path class="trail-line" d="${pathD}" />
    ${donePath ? `<path class="trail-line-done" d="${donePath}" />` : ''}
    ${circles}
  </svg>`;
}

function escapeHtml(str) {
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}

function courseCoverIcon(key) {
  return Icons[key] || Icons.peak;
}

function lessonTypeLabel(type) {
  return { reading: 'Reading', video: 'Video', quiz: 'Checkpoint quiz' }[type] || type;
}
