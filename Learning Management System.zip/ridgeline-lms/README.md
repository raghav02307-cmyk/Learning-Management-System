# Ridgeline — Learning Management System

A fully client-side LMS demo. Courses are framed as trails, modules as ridge
lines, and lessons as checkpoints — with an elevation-profile progress bar
as the running visual motif.

No backend, no build step, no npm install. All data (users, courses,
enrollments, progress) persists in the browser's `localStorage`, seeded on
first load.

## Run it

Just open `index.html` in a browser. For best results (some browsers
restrict localStorage on `file://`), serve it locally instead:

```bash
cd ridgeline-lms
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Demo accounts

| Role       | Email                  | Password     |
|------------|-------------------------|--------------|
| Student    | jordan@ridgeline.edu    | summit123    |
| Instructor | mara@ridgeline.edu      | trailblazer  |

You can also sign up a brand new student account from the login screen.

## Structure

```
ridgeline-lms/
├── index.html        Landing page + login/signup
├── dashboard.html     Learner/instructor home: stats + continue-learning
├── courses.html       Full course catalog with category filters
├── course.html        Course player: trail sidebar, lessons, quizzes
├── admin.html          Instructor studio: build courses, view roster
├── css/style.css       Design tokens + all styling
├── js/data.js          Seed data + localStorage data layer
├── js/auth.js          Client-side auth (login/signup/session)
└── js/ui.js             Nav rendering + the elevation-profile trail SVG
```

## Features

- **Auth** — login, signup, session persistence, role-based routing
  (student vs. instructor)
- **Catalog** — browse and filter courses by category
- **Course player** — module/lesson navigation, reading & video lesson
  types, multiple-choice checkpoint quizzes with instant feedback
- **Progress tracking** — per-lesson completion, per-course percentage,
  visualized as a trail elevation profile
- **Instructor studio** — create and edit courses, modules, and lessons;
  view a roster of enrolled learners and their progress

## Notes on the demo auth

Passwords are stored in plain text in `localStorage` for demo purposes
only. This is **not** how you'd handle authentication in production — swap
`js/auth.js` and `js/data.js` for real API calls to a backend with proper
password hashing and session tokens before shipping this anywhere real.
